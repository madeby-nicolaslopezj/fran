orion.dictionary.addDefinition('email', 'social', {
	type: String,
	label: "Email",
});

orion.dictionary.addDefinition('instagram', 'social', {
	type: String,
	label: "Instagram",
});