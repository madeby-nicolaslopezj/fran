orion.dictionary.addDefinition('emailSent', 'contact', {
  type: String,
  label: "Texto que sale cuando envian un formulario de contacto",
});